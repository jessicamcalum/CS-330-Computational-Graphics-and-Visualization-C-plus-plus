/*
*  Final Project
*  Course tutorial code modified by Jessica McAlum
*  SNHU CS 330
*
* Press 'P' for orthographic (2D) display and 'O' for perspective (3D) display
* WASD keys control the forward, backward, left, and right motion
* QE keys control the upward and downward movement
* Mouse cursor: Changes the orientation of the camera so it can look up and down or right and left
* Mouse scroll: Adjusts the movement speed
* 
* 
*/

#include <iostream>         // cout, cerr
#include <vector>
#include <cstdlib>          // EXIT_FAILURE
#include <GL/glew.h>        // GLEW library
#include <GLFW/glfw3.h>     // GLFW library
#define STB_IMAGE_IMPLEMENTATION
#include <stb_image.h>      // Image loading Utility functions

// GLM Math Header inclusions
#include <glm/glm.hpp>
#include <glm/gtx/transform.hpp>
#include <glm/gtc/type_ptr.hpp>

#include <camera.h>
#include <algorithm>
#include <cmath>
#include <vector>
#include <sphere.h>
#include <cylinder.h>
using namespace glm;
using namespace std; // Standard namespace

/*Shader program Macro*/
#ifndef GLSL
#define GLSL(Version, Source) "#version " #Version " core \n" #Source
#endif

// Unnamed namespace
namespace
{
    const char* const WINDOW_TITLE = "Final Project"; // Macro for window title

    // Variables for window width and height
    const int WINDOW_WIDTH = 800;
    const int WINDOW_HEIGHT = 600;

    // Mesh data for each object
    struct GLMesh
    {
        GLuint planeVAO, planeVBO, planenVertices;  // Plane/Table
        GLuint csVAO, csVBO, csnVertices;           // Chopstick
        GLuint lVAO, lVBO[2], lnVertices;           // Light
        GLuint l2VAO, l2VBO[2], l2nVertices;        // Second Light
        GLuint canVAO, canVBO[2], cannVertices;     // Candle
        GLuint bVAO, bVBO, bnVertices;              // Box
        GLuint sVAO, sVBO[2], snVertices;           // Ball
        GLuint lidVAO, lidVBO[2], lidnVertices;     // Candle lid
    };
    
    // Main GLFW window
    GLFWwindow* gWindow = nullptr;

    // Triangle mesh data
    GLMesh gMesh;

    // Texture IDs for objects
    GLuint gDifTextureIdChopstick;
    GLuint gSpecTextureIdChopstick;
    GLuint gDifTextureIdTable;
    GLuint gSpecTextureIdTable;
    GLuint gDifTextureIdCandle;
    GLuint gSpecTextureIdCandle;
    GLuint gDifTextureIdBox;
    GLuint gSpecTextureIdBox;
    GLuint gDifTextureIdBall;
    GLuint gSpecTextureIdBall;
    GLuint gDifTextureIdLid;
    GLuint gSpecTextureIdLid;

    vec2 gUVScale(1.0f, 1.0f);

    GLint gTexWrapMode = GL_REPEAT;

    // Shader programs
    GLuint gCsProgramId;
    GLuint gTableProgramId;
    GLuint gLampProgramId;
    GLuint gLamp2ProgramId;
    GLuint gCandleProgramId;
    GLuint gBoxProgramId;
    GLuint gBallProgramId;
    GLuint gLidProgramId;
    
    // Camera
    Camera gCamera(glm::vec3(0.0f, 0.0f, 3.0f));
    float gLastX = WINDOW_WIDTH / 2.0f;
    float gLastY = WINDOW_HEIGHT / 2.0f;
    bool gFirstMouse = true;

    // Timing
    float gDeltaTime = 0.0f; // time between current frame and last frame
    float gLastFrame = 0.0f;

    // Cylinders with (base radius, top radius, height, sector count (slices), stack count) 
    Cylinder cylinder1(1.0f, 1.0f, 1.6f, 36, 8);   // Candle
    Cylinder cylinder2(1.05f, 1.05f, 0.2f, 36, 1); // Lid

    // Sphere with (radius (float), sectors(int), stacks(int))
    Sphere sphere(1.0f, 36, 18);       // Tennis ball
    Sphere lightSphere(1.0f, 36, 18);  // Light 1
    Sphere lightSphere2(1.0f, 36, 18); // Light 2

    // (-left/+right, -down/+up, -back/+forward)
   // Chopstick
    glm::vec3 gCsPosition(0.5f, -0.1f, 0.0f);
    glm::vec3 gCsScale(0.9f);
    float csShine = 32.0f;

    // Plane/Table
    glm::vec3 gPlanePosition(0.0f, 0.0f, 0.0f);
    glm::vec3 gPlaneScale(2.0f);
    float tableShine = 32.0f;

    // Box
    glm::vec3 gBoxPosition(-3.4f, 0.56f, -2.2f);
    glm::vec3 gBoxScale(1.5f);
    float boxShine = 2.0f;

    // Ball
    glm::vec3 gBallPosition(-1.0f, 0.6f, -1.0f);
    glm::vec3 gBallScale(0.8f);
    float bShine = 2.0f;

    // Candle 
    glm::vec3 gCandlePosition(1.0f, 0.77f, -3.0f);
    glm::vec3 gCandleScale(1.2f);
    float candleShine = 8.0f;

    // Candle lid
    glm::vec3 gLidPosition(1.0f, 1.81f, -3.0f);
    glm::vec3 gLidScale(1.2f);
    float lidShine = 32.0f;

    // Directional light
    glm::vec3 dirLightDirection(-0.2f, -1.0f, -0.3f);
    glm::vec3 dirLightAmbient(0.8f, 0.8f, 0.8f);
    glm::vec3 dirLightDiffuse(0.4f, 0.4f, 0.4f);
    glm::vec3 dirLightSpecular(0.03f, 0.03f, 0.03f);

    // Point light positions
    glm::vec3 pointLightPositions[] = {
        glm::vec3 (0.0f, 39.0f, 5.0f),              // Light #1 position
        glm::vec3 (-15.0f, 12.0f, 0.0f)            // Light #2 position
    };

    // Point Light #1
    glm::vec3 gLightScale(1.0f);
    glm::vec3 pointLightAmbient(0.05f, 0.05f, 0.05f);
    glm::vec3 pointLightDiffuse(0.8f, 0.8f, 0.8f);
    glm::vec3 pointLightSpecular(1.0f, 1.0f, 1.0f); // Specular light Color  
    
    float pointLightConstant = 1.0f;
    float pointLightLinear = 0.09;
    float pointLightQuadratic = 0.032;

    // Point Light #2
    glm::vec3 gLight2Scale(2.0f);
    glm::vec3 pointLight2Ambient(0.05f, 0.05f, 0.05f);
    glm::vec3 pointLight2Diffuse(0.8f, 0.8f, 0.8f);
    glm::vec3 pointLight2Specular(1.0f, 0.0f, 0.0f); // Specular light Color (changed to red 
    // attenuation
    float pointLight2Constant = 1.0f;
    float pointLight2Linear = 0.09;
    float pointLight2Quadratic = 0.032;

    bool perspectiveView = true;
}

/* User-defined Function prototypes to:
 * initialize the program, set the window size,
 * redraw graphics on the window when resized,
 * and render graphics on the screen
 */
bool UInitialize(int, char* [], GLFWwindow** window);
void UResizeWindow(GLFWwindow* window, int width, int height);
void UProcessInput(GLFWwindow* window);
void URender();
bool UCreateShaderProgram(const char* vtxShaderSource, const char* fragShaderSource, GLuint& programId);
void UDestroyShaderProgram(GLuint programId);
void UCreateMesh(GLMesh& mesh);
void UDestroyMesh(GLMesh& mesh);
void UMousePositionCallback(GLFWwindow* window, double xpos, double ypos);
void UMouseScrollCallback(GLFWwindow* window, double xoffset, double yoffset);
void UMouseButtonCallback(GLFWwindow* window, int button, int action, int mods);
bool UCreateTexture(const char* filename, GLuint& textureId);
void UDestroyTexture(GLuint textureId);

/* Object Vertex Shader Source Code*/
const GLchar* objectVertexShaderSource = GLSL(440,
    layout(location = 0) in vec3 position; // Vertex data from Vertex Attrib Pointer 0
    layout(location = 1) in vec3 normal; // VAP position 1 for normals
    layout(location = 2) in vec2 textureCoordinate;

    out vec3 vertexNormal;            // For outgoing normals to fragment shader
    out vec3 vertexFragmentPos;       // For outgoing color / pixels to fragment shader
    out vec2 vertexTextureCoordinate;

    //Global variables for the  transform matrices
    uniform mat4 model;
    uniform mat4 view;
    uniform mat4 projection;

    void main()
    {
        gl_Position = projection * view * model * vec4(position, 1.0f); // transforms vertices to clip coordinates
        vertexFragmentPos = vec3(model * vec4(position, 1.0f)); // Gets fragment / pixel position in world space only (exclude view and projection)
        vertexNormal = mat3(transpose(inverse(model))) * normal; // get normal vectors in world space only and exclude normal translation properties
        vertexTextureCoordinate = textureCoordinate;
    }
);

/* Object Fragment Shader Source Code*/
const GLchar* objectFragmentShaderSource = GLSL(440,   
    
    out vec4 fragmentColor;

    struct Material {
        sampler2D diffuse;
        sampler2D specular;
        float shininess;
    };

    struct DirLight {
        vec3 direction;
        vec3 ambient;
        vec3 diffuse;
        vec3 specular;
    };

    struct PointLight {
        vec3 position;
        float constant;
        float linear;
        float quadratic;
        vec3 ambient;
        vec3 diffuse;
        vec3 specular;
    };

    in vec3 vertexFragmentPos;
    in vec3 vertexNormal;
    in vec2 vertexTextureCoordinate;

    uniform vec3 viewPosition;
    uniform DirLight dirLight;
    uniform PointLight pointLights[2];
    uniform Material material;

    // function prototypes
    vec3 CalcDirLight(DirLight light, vec3 normal, vec3 viewDir);
    vec3 CalcPointLight(PointLight light, vec3 normal, vec3 fragPos, vec3 viewDir);

    void main()
    {
        // properties
        vec3 norm = normalize(vertexNormal);
        vec3 viewDir = normalize(viewPosition - vertexFragmentPos);

        // == =====================================================
        // Lighting is set up in 2 phases: directional and point lights.
        // For each phase, a calculated function is defined that calculates the corresponding color
        // per lamp. In the main() function we take all the calculated colors and sum them up for
        // this fragment's final color.
        // == =====================================================
        // phase 1: directional lighting
        vec3 result = CalcDirLight(dirLight, norm, viewDir);
        // phase 2: point lights
        for (int i = 0; i < 2; i++)
            result += CalcPointLight(pointLights[i], norm, vertexFragmentPos, viewDir);

        fragmentColor = vec4(result, 1.0);
}

    // calculates the color when using a directional light.
    vec3 CalcDirLight(DirLight light, vec3 normal, vec3 viewDir)
    {
        vec3 lightDir = normalize(-light.direction);
        // diffuse shading
        float diff = max(dot(normal, lightDir), 0.0);
        // specular shading
        vec3 reflectDir = reflect(-lightDir, normal);
        float spec = pow(max(dot(viewDir, reflectDir), 0.0), material.shininess);
        // combine result
        vec3 ambient = light.ambient * vec3(texture(material.diffuse, vertexTextureCoordinate));
        vec3 diffuse = light.diffuse * diff * vec3(texture(material.diffuse, vertexTextureCoordinate));
        vec3 specular = light.specular * spec * vec3(texture(material.specular, vertexTextureCoordinate));
        return (ambient + diffuse + specular);
    }

    // calculates the color when using a point light.
    vec3 CalcPointLight(PointLight light, vec3 normal, vec3 fragPos, vec3 viewDir)
    {
        vec3 lightDir = normalize(light.position - fragPos);
        // diffuse shading
        float diff = max(dot(normal, lightDir), 0.0);
        // specular shading
        vec3 reflectDir = reflect(-lightDir, normal);
        float spec = pow(max(dot(viewDir, reflectDir), 0.0), material.shininess);
        // attenuation
        float distance = length(light.position - fragPos);
        float attenuation = 1.0 / (light.constant + light.linear * distance + light.quadratic * (distance * distance));
        // combine results
        vec3 ambient = light.ambient * vec3(texture(material.diffuse, vertexTextureCoordinate));
        vec3 diffuse = light.diffuse * diff * vec3(texture(material.diffuse, vertexTextureCoordinate));
        vec3 specular = light.specular * spec * vec3(texture(material.specular, vertexTextureCoordinate));
        ambient *= attenuation;
        diffuse *= attenuation;
        specular *= attenuation;
        return (ambient + diffuse + specular);
    }   
);

/* Lamp Vertex Shader Source Code*/
const GLchar* lampVertexShaderSource = GLSL(440,

    layout(location = 0) in vec3 position; // VAP position 0 for vertex position data

    //Uniform / Global variables for the  transform matrices
    uniform mat4 model;
    uniform mat4 view;
    uniform mat4 projection;

    void main()
    {
        gl_Position = projection * view * model * vec4(position, 1.0f); // Transforms vertices into clip coordinates
    }
);

/* Lamp Fragment Shader Source Code*/
const GLchar* lampFragmentShaderSource = GLSL(440,

    out vec4 fragmentColor; // For outgoing lamp color (smaller cube) to the GPU

    void main()
    {
        fragmentColor = vec4(1.0f); // Set color to white (1.0f,1.0f,1.0f) with alpha 1.0
    }
);

// Images are loaded with Y axis going down, but OpenGL's Y axis goes up, so let's flip it
void flipImageVertically(unsigned char* image, int width, int height, int channels)
{
    for (int j = 0; j < height / 2; ++j)
    {
        int index1 = j * width * channels;
        int index2 = (height - 1 - j) * width * channels;

        for (int i = width * channels; i > 0; --i)
        {
            unsigned char tmp = image[index1];
            image[index1] = image[index2];
            image[index2] = tmp;
            ++index1;
            ++index2;
        }
    }
}


// main function. Entry point to the OpenGL program
int main(int argc, char* argv[])
{
    if (!UInitialize(argc, argv, &gWindow))
        return EXIT_FAILURE;

    // Creates the object
    UCreateMesh(gMesh); // Calls the function to create the Vertex Buffer Object

    // Create the shader programs
    // --------------------------
    // Chopstick
    if (!UCreateShaderProgram(objectVertexShaderSource, objectFragmentShaderSource, gCsProgramId))
        return EXIT_FAILURE;
    // Table
    if (!UCreateShaderProgram(objectVertexShaderSource, objectFragmentShaderSource, gTableProgramId))
        return EXIT_FAILURE;
    // Light Cube
    if (!UCreateShaderProgram(lampVertexShaderSource, lampFragmentShaderSource, gLampProgramId))
        return EXIT_FAILURE;
    // Second Light Cube
    if (!UCreateShaderProgram(lampVertexShaderSource, lampFragmentShaderSource, gLamp2ProgramId))
        return EXIT_FAILURE;
    // Candle
    if (!UCreateShaderProgram(objectVertexShaderSource, objectFragmentShaderSource, gCandleProgramId))
        return EXIT_FAILURE;
    // Box
    if (!UCreateShaderProgram(objectVertexShaderSource, objectFragmentShaderSource, gBoxProgramId))
        return EXIT_FAILURE;
    // Ball
    if (!UCreateShaderProgram(objectVertexShaderSource, objectFragmentShaderSource, gBallProgramId))
        return EXIT_FAILURE;
    // Candle lid
    if (!UCreateShaderProgram(objectVertexShaderSource, objectFragmentShaderSource, gLidProgramId))
        return EXIT_FAILURE;

    // Load diffuse chopstick texture
    const char* csDiftexFilename = "C:/OpenGLSample/FinalProject/images/chopstick.jpg";
    if (!UCreateTexture(csDiftexFilename, gDifTextureIdChopstick))
    {
        cout << "Failed to load texture " << csDiftexFilename << endl;
        return EXIT_FAILURE;
    }
    // Load specular chopstick texture
    const char* csSpectexFilename = "C:/OpenGLSample/FinalProject/images/chopstick_bw.jpg";
    if (!UCreateTexture(csSpectexFilename, gSpecTextureIdChopstick))
    {
        cout << "Failed to load texture " << csSpectexFilename << endl;
        return EXIT_FAILURE;
    }


    // Load diffuse table texture
    const char* diffuseTabletexFilename = "C:/OpenGLSample/FinalProject/images/table.jpg";
    if (!UCreateTexture(diffuseTabletexFilename, gDifTextureIdTable))
    {
        cout << "Failed to load texture " << diffuseTabletexFilename << endl;
        return EXIT_FAILURE;
    }
    // Load specular table texture
    const char* specularTabletexFilename = "C:/OpenGLSample/FinalProject/images/table_bw.jpg";
    if (!UCreateTexture(specularTabletexFilename, gSpecTextureIdTable))
    {
        cout << "Failed to load texture " << specularTabletexFilename << endl;
        return EXIT_FAILURE;
    }

    // Load diffuse box texture
    const char* boxDiftexFilename = "C:/OpenGLSample/FinalProject/images/box.jpg";
    if (!UCreateTexture(boxDiftexFilename, gDifTextureIdBox))
    {
        cout << "Failed to load texture " << boxDiftexFilename << endl;
        return EXIT_FAILURE;
    }
    // Load specular box texture
    const char* boxSpectexFilename = "C:/OpenGLSample/FinalProject/images/box_bw.jpg";
    if (!UCreateTexture(boxSpectexFilename, gSpecTextureIdBox))
    {
        cout << "Failed to load texture " << boxSpectexFilename << endl;
        return EXIT_FAILURE;
    }

    // Load diffuse candle texture
    const char* candleDiftexFilename = "C:/OpenGLSample/FinalProject/images/candle.jpg";
    if (!UCreateTexture(candleDiftexFilename, gDifTextureIdCandle))
    {
        cout << "Failed to load texture " << candleDiftexFilename << endl;
        return EXIT_FAILURE;
    }
    // Load specular candle texture
    const char* candleSpectexFilename = "C:/OpenGLSample/FinalProject/images/candle_bw.jpg";
    if (!UCreateTexture(candleSpectexFilename, gSpecTextureIdCandle))
    {
        cout << "Failed to load texture " << candleSpectexFilename << endl;
        return EXIT_FAILURE;
    }

    // Load diffuse ball texture
    const char* ballDiftexFilename = "C:/OpenGLSample/FinalProject/images/ball.jpg";
    if (!UCreateTexture(ballDiftexFilename, gDifTextureIdBall))
    {
        cout << "Failed to load texture " << ballDiftexFilename << endl;
        return EXIT_FAILURE;
    }
    // Load specular ball texture
    const char* ballSpectexFilename = "C:/OpenGLSample/FinalProject/images/ball_bw.jpg";
    if (!UCreateTexture(ballSpectexFilename, gSpecTextureIdBall))
    {
        cout << "Failed to load texture " << ballSpectexFilename << endl;
        return EXIT_FAILURE;
    }

    // Load diffuse lid texture
    const char* lidDiftexFilename = "C:/OpenGLSample/FinalProject/images/lid.jpg";
    if (!UCreateTexture(lidDiftexFilename, gDifTextureIdLid))
    {
        cout << "Failed to load texture " << lidDiftexFilename << endl;
        return EXIT_FAILURE;
    }
    // Load specular lid texture
    const char* lidSpectexFilename = "C:/OpenGLSample/FinalProject/images/lid_bw.jpg";
    if (!UCreateTexture(lidSpectexFilename, gSpecTextureIdLid))
    {
        cout << "Failed to load texture " << lidSpectexFilename << endl;
        return EXIT_FAILURE;
    }
    
    // tell opengl for each sampler to which texture unit it belongs to 
    glUseProgram(gCsProgramId);
    // We set the texture
    glUniform1i(glGetUniformLocation(gCsProgramId, "material.diffuse"), 0);
    glUniform1i(glGetUniformLocation(gCsProgramId, "material.specular"), 1);

    // tell opengl for each sampler to which texture unit it belongs to (only has to be done once)
    glUseProgram(gTableProgramId);
    // We set the texture=
    glUniform1i(glGetUniformLocation(gTableProgramId, "material.diffuse"), 0);
    glUniform1i(glGetUniformLocation(gTableProgramId, "material.specular"), 1);
    
    // tell opengl for each sampler to which texture unit it belongs to (only has to be done once)
    glUseProgram(gCandleProgramId);
    // We set the texture 
    glUniform1i(glGetUniformLocation(gCandleProgramId, "material.diffuse"), 0);
    glUniform1i(glGetUniformLocation(gCandleProgramId, "material.specular"), 1);

    // tell opengl for each sampler to which texture unit it belongs to (only has to be done once)
    glUseProgram(gBoxProgramId);
    // We set the texture 
    glUniform1i(glGetUniformLocation(gBoxProgramId, "material.diffuse"), 0);
    glUniform1i(glGetUniformLocation(gBoxProgramId, "material.specular"), 1);

    // tell opengl for each sampler to which texture unit it belongs to (only has to be done once)
    glUseProgram(gBallProgramId);
    // We set the texture
    glUniform1i(glGetUniformLocation(gBallProgramId, "material.diffuse"), 0);
    glUniform1i(glGetUniformLocation(gBallProgramId, "material.specular"), 1);

    // tell opengl for each sampler to which texture unit it belongs to (only has to be done once)
    glUseProgram(gLidProgramId);
    // We set the texture 
    glUniform1i(glGetUniformLocation(gLidProgramId, "material.diffuse"), 0);
    glUniform1i(glGetUniformLocation(gLidProgramId, "material.specular"), 1);

    // Sets the background color of the window to black (it will be implicitely used by glClear)
    glClearColor(0.0f, 0.0f, 0.0f, 1.0f);

    // render loop
    // -----------
    while (!glfwWindowShouldClose(gWindow))
    {
        // per-frame timing
        // -----------------
        float currentFrame = glfwGetTime();
        gDeltaTime = currentFrame - gLastFrame;
        gLastFrame = currentFrame;


        // input
        // -----
        UProcessInput(gWindow);

        // Render this frame
        URender();

        glfwPollEvents();
    }

    // Release mesh data
    UDestroyMesh(gMesh);

    // Release shader programs
    UDestroyShaderProgram(gCsProgramId);
    UDestroyShaderProgram(gTableProgramId);
    UDestroyShaderProgram(gLampProgramId);
    UDestroyShaderProgram(gLamp2ProgramId);
    UDestroyShaderProgram(gCandleProgramId);
    UDestroyShaderProgram(gBallProgramId);
    UDestroyShaderProgram(gLidProgramId);

    // Release textures
    UDestroyTexture(gDifTextureIdChopstick);
    UDestroyTexture(gSpecTextureIdChopstick);
    UDestroyTexture(gDifTextureIdTable);
    UDestroyTexture(gSpecTextureIdTable);
    UDestroyTexture(gDifTextureIdCandle);
    UDestroyTexture(gSpecTextureIdCandle);
    UDestroyTexture(gDifTextureIdBox);
    UDestroyTexture(gSpecTextureIdBox);
    UDestroyTexture(gDifTextureIdBall);
    UDestroyTexture(gSpecTextureIdBall);
    UDestroyTexture(gDifTextureIdLid);
    UDestroyTexture(gSpecTextureIdLid);

    exit(EXIT_SUCCESS); // Terminates the program successfully
}

// Initialize GLFW, GLEW, and create a window
bool UInitialize(int argc, char* argv[], GLFWwindow** window)
{
    // GLFW: initialize and configure
    // ------------------------------
    glfwInit();
    glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 4);
    glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 4);
    glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);

#ifdef __APPLE__
    glfwWindowHint(GLFW_OPENGL_FORWARD_COMPAT, GL_TRUE);
#endif

    // GLFW: window creation
    // ---------------------
    * window = glfwCreateWindow(WINDOW_WIDTH, WINDOW_HEIGHT, WINDOW_TITLE, NULL, NULL);
    if (*window == NULL)
    {
        std::cout << "Failed to create GLFW window" << std::endl;
        glfwTerminate();
        return false;
    }
    glfwMakeContextCurrent(*window);
    glfwSetFramebufferSizeCallback(*window, UResizeWindow);
    glfwSetCursorPosCallback(*window, UMousePositionCallback);
    glfwSetScrollCallback(*window, UMouseScrollCallback);
    glfwSetMouseButtonCallback(*window, UMouseButtonCallback);

    // tell GLFW to capture our mouse
    glfwSetInputMode(*window, GLFW_CURSOR, GLFW_CURSOR_DISABLED);

    // GLEW: initialize
    // ----------------
    // Note: if using GLEW version 1.13 or earlier
    glewExperimental = GL_TRUE;
    GLenum GlewInitResult = glewInit();

    if (GLEW_OK != GlewInitResult)
    {
        std::cerr << glewGetErrorString(GlewInitResult) << std::endl;
        return false;
    }

    // Displays GPU OpenGL version
    cout << "INFO: OpenGL Version: " << glGetString(GL_VERSION) << endl;

    return true;
}

// process all input: query GLFW whether relevant keys are pressed/released this frame and react accordingly
void UProcessInput(GLFWwindow* window)
{
    if (glfwGetKey(window, GLFW_KEY_ESCAPE) == GLFW_PRESS)
        glfwSetWindowShouldClose(window, true);

    if (glfwGetKey(window, GLFW_KEY_W) == GLFW_PRESS)
        gCamera.ProcessKeyboard(FORWARD, gDeltaTime);
    if (glfwGetKey(window, GLFW_KEY_S) == GLFW_PRESS)
        gCamera.ProcessKeyboard(BACKWARD, gDeltaTime);
    if (glfwGetKey(window, GLFW_KEY_A) == GLFW_PRESS)
        gCamera.ProcessKeyboard(LEFT, gDeltaTime);
    if (glfwGetKey(window, GLFW_KEY_D) == GLFW_PRESS)
        gCamera.ProcessKeyboard(RIGHT, gDeltaTime);
    if (glfwGetKey(window, GLFW_KEY_Q) == GLFW_PRESS)
        gCamera.ProcessKeyboard(UPWARD, gDeltaTime);
    if (glfwGetKey(window, GLFW_KEY_E) == GLFW_PRESS)
        gCamera.ProcessKeyboard(DOWNWARD, gDeltaTime);

    if (glfwGetKey(window, GLFW_KEY_P) == GLFW_PRESS)
        perspectiveView = false;
    if (glfwGetKey(window, GLFW_KEY_O) == GLFW_PRESS)
        perspectiveView = true;
}

// glfw: whenever the window size changed (by OS or user resize) this callback function executes
void UResizeWindow(GLFWwindow* window, int width, int height)
{
    glViewport(0, 0, width, height);
}

// glfw: whenever the mouse moves, this callback is called
// -------------------------------------------------------
void UMousePositionCallback(GLFWwindow* window, double xpos, double ypos)
{
    if (gFirstMouse)
    {
        gLastX = xpos;
        gLastY = ypos;
        gFirstMouse = false;
    }

    float xoffset = xpos - gLastX;
    float yoffset = gLastY - ypos; // reversed since y-coordinates go from bottom to top

    gLastX = xpos;
    gLastY = ypos;

    gCamera.ProcessMouseMovement(xoffset, yoffset);
}

// glfw: whenever the mouse scroll wheel scrolls, this callback is called
// ----------------------------------------------------------------------
void UMouseScrollCallback(GLFWwindow* window, double xoffset, double yoffset)
{
    gCamera.ProcessMouseScroll(yoffset);
}

// glfw: handle mouse button events
// --------------------------------
void UMouseButtonCallback(GLFWwindow* window, int button, int action, int mods)
{
    switch (button)
    {
    case GLFW_MOUSE_BUTTON_LEFT:
    {
        if (action == GLFW_PRESS)
            cout << "Left mouse button pressed" << endl;
        else
            cout << "Left mouse button released" << endl;
    }
    break;

    case GLFW_MOUSE_BUTTON_MIDDLE:
    {
        if (action == GLFW_PRESS)
            cout << "Middle mouse button pressed" << endl;
        else
            cout << "Middle mouse button released" << endl;
    }
    break;

    case GLFW_MOUSE_BUTTON_RIGHT:
    {
        if (action == GLFW_PRESS)
            cout << "Right mouse button pressed" << endl;
        else
            cout << "Right mouse button released" << endl;
    }
    break;

    default:
        cout << "Unhandled mouse button event" << endl;
        break;
    }
}

// Functioned called to render a frame
void URender()
{
    // Enable z-depth
    glEnable(GL_DEPTH_TEST);

    // Clear the frame and z buffers
    glClearColor(0.0f, 0.0f, 0.0f, 1.0f);
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

    // Initialize projection matrix
    glm::mat4 projection;
    // camera/view transformation
    glm::mat4 view = gCamera.GetViewMatrix();

    // To toggle between orthographic and perspective displays
    if (!perspectiveView) {
        projection = ortho(-5.0f, 5.0f, -5.0f, 5.0f, 0.1f, 100.0f);
    }
    else
        projection = glm::perspective(radians(gCamera.Zoom), (GLfloat)WINDOW_WIDTH / (GLfloat)WINDOW_HEIGHT, 0.1f, 100.0f);

    // CHOPSTICK: draw chopstick
    // ----------------------------------------------------
    // Set the shader to be used
    glUseProgram(gCsProgramId);
    
    // Activate the VBOs contained within the mesh's VAO
    glBindVertexArray(gMesh.csVAO);

    glActiveTexture(GL_TEXTURE0);
    glBindTexture(GL_TEXTURE_2D, gDifTextureIdChopstick);
    glActiveTexture(GL_TEXTURE1);
    glBindTexture(GL_TEXTURE_2D, gSpecTextureIdChopstick);

    // Model matrix
    glm::mat4 model = glm::translate(gCsPosition) * glm::rotate(radians(22.0f), glm::vec3(0.0f, 1.0f, 0.0f)) * glm::scale(gCsScale);

    // Retrieves and passes transform matrices to the Shader program
    GLint modelLoc = glGetUniformLocation(gCsProgramId, "model");
    GLint viewLoc = glGetUniformLocation(gCsProgramId, "view");
    GLint projLoc = glGetUniformLocation(gCsProgramId, "projection");

    // Pass matrix data to the Shader program's matrix uniforms
    glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));
    glUniformMatrix4fv(viewLoc, 1, GL_FALSE, glm::value_ptr(view));
    glUniformMatrix4fv(projLoc, 1, GL_FALSE, glm::value_ptr(projection));

    // Reference matrix uniforms from the Shader program for the object color, light color, light position, and camera position
    GLint matShininessLoc = glGetUniformLocation(gCsProgramId, "material.shininess");
    GLint lightDirectionLoc = glGetUniformLocation(gCsProgramId, "dirLight.direction");
    GLint viewPositionLoc = glGetUniformLocation(gCsProgramId, "viewPosition");
    GLint ambientLightLoc = glGetUniformLocation(gCsProgramId, "dirLight.ambient");
    GLint diffuseLightLoc = glGetUniformLocation(gCsProgramId, "dirLight.diffuse");
    GLint specularLightLoc = glGetUniformLocation(gCsProgramId, "dirLight.specular");
    
    GLint pointLightPosLoc = glGetUniformLocation(gCsProgramId, "pointLights[0].position");
    GLint pointLightAmbientLoc = glGetUniformLocation(gCsProgramId, "pointLights[0].ambient");
    GLint pointLightDiffuseLoc = glGetUniformLocation(gCsProgramId, "pointLights[0].diffuse");
    GLint pointLightSpecularLoc = glGetUniformLocation(gCsProgramId, "pointLights[0].specular");
    GLfloat pointLightConstantLoc = glGetUniformLocation(gCsProgramId, "pointLights[0].constant");
    GLfloat pointLightLinearLoc = glGetUniformLocation(gCsProgramId, "pointLights[0].linear");
    GLfloat pointLightQuadraticLoc = glGetUniformLocation(gCsProgramId, "pointLights[0].quadratic");

    GLint pointLight2PosLoc = glGetUniformLocation(gCsProgramId, "pointLights[1].position");
    GLint pointLight2AmbientLoc = glGetUniformLocation(gCsProgramId, "pointLights[1].ambient");
    GLint pointLight2DiffuseLoc = glGetUniformLocation(gCsProgramId, "pointLights[1].diffuse");
    GLint pointLight2SpecularLoc = glGetUniformLocation(gCsProgramId, "pointLights[1].specular");
    GLfloat pointLight2ConstantLoc = glGetUniformLocation(gCsProgramId, "pointLights[1].constant");
    GLfloat pointLight2LinearLoc = glGetUniformLocation(gCsProgramId, "pointLights[1].linear");
    GLfloat pointLight2QuadraticLoc = glGetUniformLocation(gCsProgramId, "pointLights[1].quadratic");

    // Pass color, light, and camera data to the Shader program's corresponding uniforms
    glUniform1f(matShininessLoc, csShine);
    glUniform3f(lightDirectionLoc, dirLightDirection.x, dirLightDirection.y, dirLightDirection.z);
    const glm::vec3 cameraPosition = gCamera.Position;
    glUniform3f(viewPositionLoc, cameraPosition.x, cameraPosition.y, cameraPosition.z);
    glUniform3f(ambientLightLoc, dirLightAmbient.x, dirLightAmbient.y, dirLightAmbient.z);
    glUniform3f(diffuseLightLoc, dirLightDiffuse.x, dirLightDiffuse.y, dirLightDiffuse.z);
    glUniform3f(specularLightLoc, dirLightSpecular.x, dirLightSpecular.y, dirLightSpecular.z);
   
    glUniform3f(pointLightPosLoc, pointLightPositions[0].x, pointLightPositions[0].y, pointLightPositions[0].z);
    glUniform3f(pointLightAmbientLoc, pointLightAmbient.x, pointLightAmbient.y, pointLightAmbient.z);
    glUniform3f(pointLightDiffuseLoc, pointLightDiffuse.x, pointLightDiffuse.y, pointLightDiffuse.z);
    glUniform3f(pointLightSpecularLoc, pointLightSpecular.x, pointLightSpecular.y, pointLightSpecular.z);
    glUniform1f(pointLightConstantLoc, pointLightConstant);
    glUniform1f(pointLightLinearLoc, pointLightLinear);
    glUniform1f(pointLightLinearLoc, pointLightQuadratic);

    glUniform3f(pointLight2PosLoc, pointLightPositions[1].x, pointLightPositions[1].y, pointLightPositions[1].z);
    glUniform3f(pointLight2AmbientLoc, pointLight2Ambient.x, pointLight2Ambient.y, pointLight2Ambient.z);
    glUniform3f(pointLight2DiffuseLoc, pointLight2Diffuse.x, pointLight2Diffuse.y, pointLight2Diffuse.z);
    glUniform3f(pointLight2SpecularLoc, pointLight2Specular.x, pointLight2Specular.y, pointLight2Specular.z);
    glUniform1f(pointLight2ConstantLoc, pointLight2Constant);
    glUniform1f(pointLight2LinearLoc, pointLight2Linear);
    glUniform1f(pointLight2LinearLoc, pointLight2Quadratic);

    glDrawArrays(GL_TRIANGLES, 0, gMesh.csnVertices);


    // LIGHT 1: Draw light 1
    //------------------------------------------------------
    glUseProgram(gLampProgramId);

    glBindVertexArray(gMesh.lVAO);

    //Transform the smaller cube used as a visual que for the light source
    model = glm::translate(pointLightPositions[0]) * glm::scale(gLightScale);

    // Reference matrix uniforms from the Lamp Shader program
    modelLoc = glGetUniformLocation(gLampProgramId, "model");
    viewLoc = glGetUniformLocation(gLampProgramId, "view");
    projLoc = glGetUniformLocation(gLampProgramId, "projection");

    // Pass matrix data to the Lamp Shader program's matrix uniforms
    glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));
    glUniformMatrix4fv(viewLoc, 1, GL_FALSE, glm::value_ptr(view));
    glUniformMatrix4fv(projLoc, 1, GL_FALSE, glm::value_ptr(projection));

    // Draws the triangles
    glDrawElements(GL_TRIANGLES, gMesh.lnVertices, GL_UNSIGNED_INT, NULL); // Draws the triangle

    // Deactivate the Vertex Array Object and shader program
    glBindVertexArray(0);


    // LIGHT 2: Draw light 2
    //------------------------------------------------------
    glUseProgram(gLamp2ProgramId);

    glBindVertexArray(gMesh.l2VAO);

    //Transform the smaller cube used as a visual que for the light source
    model = glm::translate(pointLightPositions[1]) * glm::scale(gLight2Scale);

    // Reference matrix uniforms from the Lamp Shader program
    modelLoc = glGetUniformLocation(gLamp2ProgramId, "model");
    viewLoc = glGetUniformLocation(gLamp2ProgramId, "view");
    projLoc = glGetUniformLocation(gLamp2ProgramId, "projection");

    // Pass matrix data to the Lamp Shader program's matrix uniforms
    glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));
    glUniformMatrix4fv(viewLoc, 1, GL_FALSE, glm::value_ptr(view));
    glUniformMatrix4fv(projLoc, 1, GL_FALSE, glm::value_ptr(projection));

    // Draws the triangles
    glDrawElements(GL_TRIANGLES, gMesh.l2nVertices, GL_UNSIGNED_INT, NULL); // Draws the triangle

    // Deactivate the Vertex Array Object and shader program
    glBindVertexArray(0);


    // TABLE: Draw table
    // ---------------------------------------------------------
    glUseProgram(gTableProgramId);
 
    model = glm::translate(gPlanePosition) * glm::scale(gPlaneScale);

    // Activate the VBOs contained within the mesh's VAO
    glBindVertexArray(gMesh.planeVAO);

    glActiveTexture(GL_TEXTURE0);
    glBindTexture(GL_TEXTURE_2D, gDifTextureIdTable);
    glActiveTexture(GL_TEXTURE1);
    glBindTexture(GL_TEXTURE_2D, gSpecTextureIdTable);
    
    // Retrieves and passes transform matrices to the Shader program
    modelLoc = glGetUniformLocation(gTableProgramId, "model");
    viewLoc = glGetUniformLocation(gTableProgramId, "view");
    projLoc = glGetUniformLocation(gTableProgramId, "projection");

    // Pass matrix data to the Shader program's matrix uniforms
    glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));
    glUniformMatrix4fv(viewLoc, 1, GL_FALSE, glm::value_ptr(view));
    glUniformMatrix4fv(projLoc, 1, GL_FALSE, glm::value_ptr(projection));

    // Reference matrix uniforms from the Shader program for the object color, light color, light position, and camera position
    matShininessLoc = glGetUniformLocation(gTableProgramId, "material.shininess");
    lightDirectionLoc = glGetUniformLocation(gTableProgramId, "dirLight.direction");
    viewPositionLoc = glGetUniformLocation(gTableProgramId, "viewPosition");
    ambientLightLoc = glGetUniformLocation(gTableProgramId, "dirLight.ambient");
    diffuseLightLoc = glGetUniformLocation(gTableProgramId, "dirLight.diffuse");
    specularLightLoc = glGetUniformLocation(gTableProgramId, "dirLight.specular");

    pointLightPosLoc = glGetUniformLocation(gTableProgramId, "pointLights[0].position");
    pointLightAmbientLoc = glGetUniformLocation(gTableProgramId, "pointLights[0].ambient");
    pointLightDiffuseLoc = glGetUniformLocation(gTableProgramId, "pointLights[0].diffuse");
    pointLightSpecularLoc = glGetUniformLocation(gTableProgramId, "pointLights[0].specular");
    pointLightConstantLoc = glGetUniformLocation(gTableProgramId, "pointLights[0].constant");
    pointLightLinearLoc = glGetUniformLocation(gTableProgramId, "pointLights[0].linear");
    pointLightQuadraticLoc = glGetUniformLocation(gTableProgramId, "pointLights[0].quadratic");

    pointLight2PosLoc = glGetUniformLocation(gTableProgramId, "pointLights[1].position");
    pointLight2AmbientLoc = glGetUniformLocation(gTableProgramId, "pointLights[1].ambient");
    pointLight2DiffuseLoc = glGetUniformLocation(gTableProgramId, "pointLights[1].diffuse");
    pointLight2SpecularLoc = glGetUniformLocation(gTableProgramId, "pointLights[1].specular");
    pointLight2ConstantLoc = glGetUniformLocation(gTableProgramId, "pointLights[1].constant");
    pointLight2LinearLoc = glGetUniformLocation(gTableProgramId, "pointLights[1].linear");
    pointLight2QuadraticLoc = glGetUniformLocation(gTableProgramId, "pointLights[1].quadratic");

    // Pass color, light, and camera data to the Shader program's corresponding uniforms
    glUniform1f(matShininessLoc, tableShine);
    glUniform3f(lightDirectionLoc, dirLightDirection.x, dirLightDirection.y, dirLightDirection.z);
    cameraPosition == gCamera.Position;
    glUniform3f(viewPositionLoc, cameraPosition.x, cameraPosition.y, cameraPosition.z);
    glUniform3f(ambientLightLoc, dirLightAmbient.x, dirLightAmbient.y, dirLightAmbient.z);
    glUniform3f(diffuseLightLoc, dirLightDiffuse.x, dirLightDiffuse.y, dirLightDiffuse.z);
    glUniform3f(specularLightLoc, dirLightSpecular.x, dirLightSpecular.y, dirLightSpecular.z);

    glUniform3f(pointLightPosLoc, pointLightPositions[0].x, pointLightPositions[0].y, pointLightPositions[0].z);
    glUniform3f(pointLightAmbientLoc, pointLightAmbient.x, pointLightAmbient.y, pointLightAmbient.z);
    glUniform3f(pointLightDiffuseLoc, pointLightDiffuse.x, pointLightDiffuse.y, pointLightDiffuse.z);
    glUniform3f(pointLightSpecularLoc, pointLightSpecular.x, pointLightSpecular.y, pointLightSpecular.z);
    glUniform1f(pointLightConstantLoc, pointLightConstant);
    glUniform1f(pointLightLinearLoc, pointLightLinear);
    glUniform1f(pointLightLinearLoc, pointLightQuadratic);

    glUniform3f(pointLight2PosLoc, pointLightPositions[1].x, pointLightPositions[1].y, pointLightPositions[1].z);
    glUniform3f(pointLight2AmbientLoc, pointLight2Ambient.x, pointLight2Ambient.y, pointLight2Ambient.z);
    glUniform3f(pointLight2DiffuseLoc, pointLight2Diffuse.x, pointLight2Diffuse.y, pointLight2Diffuse.z);
    glUniform3f(pointLight2SpecularLoc, pointLight2Specular.x, pointLight2Specular.y, pointLight2Specular.z);
    glUniform1f(pointLight2ConstantLoc, pointLight2Constant);
    glUniform1f(pointLight2LinearLoc, pointLight2Linear);
    glUniform1f(pointLight2LinearLoc, pointLight2Quadratic);

    // Draws the triangles
    glDrawArrays(GL_TRIANGLES, 0, gMesh.planenVertices);

    glUseProgram(0);
    // Deactivate the Vertex Array Object
    glBindVertexArray(0);


    // BOX: Draw box
    // ---------------------------------------------------------
    glUseProgram(gBoxProgramId);
    
    model = glm::translate(gBoxPosition) * glm::rotate(radians(60.0f), glm::vec3(0.0f, 0.1f, 0.0f)) * glm::scale(gBoxScale);

    // Activate the VBOs contained within the mesh's VAO
    glBindVertexArray(gMesh.bVAO);

    glActiveTexture(GL_TEXTURE0);
    glBindTexture(GL_TEXTURE_2D, gDifTextureIdBox);
    glActiveTexture(GL_TEXTURE1);
    glBindTexture(GL_TEXTURE_2D, gSpecTextureIdBox);

    // Retrieves and passes transform matrices to the Shader program
    modelLoc = glGetUniformLocation(gBoxProgramId, "model");
    viewLoc = glGetUniformLocation(gBoxProgramId, "view");
    projLoc = glGetUniformLocation(gBoxProgramId, "projection");

    // Pass matrix data to the Shader program's matrix uniforms
    glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));
    glUniformMatrix4fv(viewLoc, 1, GL_FALSE, glm::value_ptr(view));
    glUniformMatrix4fv(projLoc, 1, GL_FALSE, glm::value_ptr(projection));

    // Reference matrix uniforms from the Shader program for the object color, light color, light position, and camera position
    matShininessLoc = glGetUniformLocation(gBoxProgramId, "material.shininess");
    lightDirectionLoc = glGetUniformLocation(gBoxProgramId, "dirLight.direction");
    viewPositionLoc = glGetUniformLocation(gBoxProgramId, "viewPosition");
    ambientLightLoc = glGetUniformLocation(gBoxProgramId, "dirLight.ambient");
    diffuseLightLoc = glGetUniformLocation(gBoxProgramId, "dirLight.diffuse");
    specularLightLoc = glGetUniformLocation(gBoxProgramId, "dirLight.specular");

    pointLightPosLoc = glGetUniformLocation(gBoxProgramId, "pointLights[0].position");
    pointLightAmbientLoc = glGetUniformLocation(gBoxProgramId, "pointLights[0].ambient");
    pointLightDiffuseLoc = glGetUniformLocation(gBoxProgramId, "pointLights[0].diffuse");
    pointLightSpecularLoc = glGetUniformLocation(gBoxProgramId, "pointLights[0].specular");
    pointLightConstantLoc = glGetUniformLocation(gBoxProgramId, "pointLights[0].constant");
    pointLightLinearLoc = glGetUniformLocation(gBoxProgramId, "pointLights[0].linear");
    pointLightQuadraticLoc = glGetUniformLocation(gBoxProgramId, "pointLights[0].quadratic");

    pointLight2PosLoc = glGetUniformLocation(gBoxProgramId, "pointLights[1].position");
    pointLight2AmbientLoc = glGetUniformLocation(gBoxProgramId, "pointLights[1].ambient");
    pointLight2DiffuseLoc = glGetUniformLocation(gBoxProgramId, "pointLights[1].diffuse");
    pointLight2SpecularLoc = glGetUniformLocation(gBoxProgramId, "pointLights[1].specular");
    pointLight2ConstantLoc = glGetUniformLocation(gBoxProgramId, "pointLights[1].constant");
    pointLight2LinearLoc = glGetUniformLocation(gBoxProgramId, "pointLights[1].linear");
    pointLight2QuadraticLoc = glGetUniformLocation(gBoxProgramId, "pointLights[1].quadratic");

    // Pass color, light, and camera data to the Shader program's corresponding uniforms
    glUniform1f(matShininessLoc, boxShine);
    glUniform3f(lightDirectionLoc, dirLightDirection.x, dirLightDirection.y, dirLightDirection.z);
    cameraPosition == gCamera.Position;
    glUniform3f(viewPositionLoc, cameraPosition.x, cameraPosition.y, cameraPosition.z);
    glUniform3f(ambientLightLoc, dirLightAmbient.x, dirLightAmbient.y, dirLightAmbient.z);
    glUniform3f(diffuseLightLoc, dirLightDiffuse.x, dirLightDiffuse.y, dirLightDiffuse.z);
    glUniform3f(specularLightLoc, dirLightSpecular.x, dirLightSpecular.y, dirLightSpecular.z);

    glUniform3f(pointLightPosLoc, pointLightPositions[0].x, pointLightPositions[0].y, pointLightPositions[0].z);
    glUniform3f(pointLightAmbientLoc, pointLightAmbient.x, pointLightAmbient.y, pointLightAmbient.z);
    glUniform3f(pointLightDiffuseLoc, pointLightDiffuse.x, pointLightDiffuse.y, pointLightDiffuse.z);
    glUniform3f(pointLightSpecularLoc, pointLightSpecular.x, pointLightSpecular.y, pointLightSpecular.z);
    glUniform1f(pointLightConstantLoc, pointLightConstant);
    glUniform1f(pointLightLinearLoc, pointLightLinear);
    glUniform1f(pointLightLinearLoc, pointLightQuadratic);

    glUniform3f(pointLight2PosLoc, pointLightPositions[1].x, pointLightPositions[1].y, pointLightPositions[1].z);
    glUniform3f(pointLight2AmbientLoc, pointLight2Ambient.x, pointLight2Ambient.y, pointLight2Ambient.z);
    glUniform3f(pointLight2DiffuseLoc, pointLight2Diffuse.x, pointLight2Diffuse.y, pointLight2Diffuse.z);
    glUniform3f(pointLight2SpecularLoc, pointLight2Specular.x, pointLight2Specular.y, pointLight2Specular.z);
    glUniform1f(pointLight2ConstantLoc, pointLight2Constant);
    glUniform1f(pointLight2LinearLoc, pointLight2Linear);
    glUniform1f(pointLight2LinearLoc, pointLight2Quadratic);

    // Draws the triangles
    glDrawArrays(GL_TRIANGLES, 0, gMesh.bnVertices);

    glUseProgram(0);
    // Deactivate the Vertex Array Object
    glBindVertexArray(0);


    // CANDLE: Draw candle
    // ---------------------------------------------------------
    glUseProgram(gCandleProgramId);
    
    model = glm::translate(gCandlePosition) * glm::rotate(radians(90.f), glm::vec3(1.0f, 0.0f, 0.0f)) * glm::scale(gCandleScale);

    // Activate the VBOs contained within the mesh's VAO
    glBindVertexArray(gMesh.canVAO);

    glActiveTexture(GL_TEXTURE0);
    glBindTexture(GL_TEXTURE_2D, gDifTextureIdCandle);
    glActiveTexture(GL_TEXTURE1);
    glBindTexture(GL_TEXTURE_2D, gSpecTextureIdCandle);

    // Retrieves and passes transform matrices to the Shader program
    modelLoc = glGetUniformLocation(gCandleProgramId, "model");
    viewLoc = glGetUniformLocation(gCandleProgramId, "view");
    projLoc = glGetUniformLocation(gCandleProgramId, "projection");

    // Pass matrix data to the Shader program's matrix uniforms
    glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));
    glUniformMatrix4fv(viewLoc, 1, GL_FALSE, glm::value_ptr(view));
    glUniformMatrix4fv(projLoc, 1, GL_FALSE, glm::value_ptr(projection));

    // Reference matrix uniforms from the Shader program for the object color, light color, light position, and camera position
    matShininessLoc = glGetUniformLocation(gCandleProgramId, "material.shininess");
    lightDirectionLoc = glGetUniformLocation(gCandleProgramId, "dirLight.direction");
    viewPositionLoc = glGetUniformLocation(gCandleProgramId, "viewPosition");
    ambientLightLoc = glGetUniformLocation(gCandleProgramId, "dirLight.ambient");
    diffuseLightLoc = glGetUniformLocation(gCandleProgramId, "dirLight.diffuse");
    specularLightLoc = glGetUniformLocation(gCandleProgramId, "dirLight.specular");

    pointLightPosLoc = glGetUniformLocation(gCandleProgramId, "pointLights[0].position");
    pointLightAmbientLoc = glGetUniformLocation(gCandleProgramId, "pointLights[0].ambient");
    pointLightDiffuseLoc = glGetUniformLocation(gCandleProgramId, "pointLights[0].diffuse");
    pointLightSpecularLoc = glGetUniformLocation(gCandleProgramId, "pointLights[0].specular");
    pointLightConstantLoc = glGetUniformLocation(gCandleProgramId, "pointLights[0].constant");
    pointLightLinearLoc = glGetUniformLocation(gCandleProgramId, "pointLights[0].linear");
    pointLightQuadraticLoc = glGetUniformLocation(gCandleProgramId, "pointLights[0].quadratic");

    pointLight2PosLoc = glGetUniformLocation(gCandleProgramId, "pointLights[1].position");
    pointLight2AmbientLoc = glGetUniformLocation(gCandleProgramId, "pointLights[1].ambient");
    pointLight2DiffuseLoc = glGetUniformLocation(gCandleProgramId, "pointLights[1].diffuse");
    pointLight2SpecularLoc = glGetUniformLocation(gCandleProgramId, "pointLights[1].specular");
    pointLight2ConstantLoc = glGetUniformLocation(gCandleProgramId, "pointLights[1].constant");
    pointLight2LinearLoc = glGetUniformLocation(gCandleProgramId, "pointLights[1].linear");
    pointLight2QuadraticLoc = glGetUniformLocation(gCandleProgramId, "pointLights[1].quadratic");

    // Pass color, light, and camera data to the Shader program's corresponding uniforms
    glUniform1f(matShininessLoc, candleShine);
    glUniform3f(lightDirectionLoc, dirLightDirection.x, dirLightDirection.y, dirLightDirection.z);
    cameraPosition == gCamera.Position;
    glUniform3f(viewPositionLoc, cameraPosition.x, cameraPosition.y, cameraPosition.z);
    glUniform3f(ambientLightLoc, dirLightAmbient.x, dirLightAmbient.y, dirLightAmbient.z);
    glUniform3f(diffuseLightLoc, dirLightDiffuse.x, dirLightDiffuse.y, dirLightDiffuse.z);
    glUniform3f(specularLightLoc, dirLightSpecular.x, dirLightSpecular.y, dirLightSpecular.z);

    glUniform3f(pointLightPosLoc, pointLightPositions[0].x, pointLightPositions[0].y, pointLightPositions[0].z);
    glUniform3f(pointLightAmbientLoc, pointLightAmbient.x, pointLightAmbient.y, pointLightAmbient.z);
    glUniform3f(pointLightDiffuseLoc, pointLightDiffuse.x, pointLightDiffuse.y, pointLightDiffuse.z);
    glUniform3f(pointLightSpecularLoc, pointLightSpecular.x, pointLightSpecular.y, pointLightSpecular.z);
    glUniform1f(pointLightConstantLoc, pointLightConstant);
    glUniform1f(pointLightLinearLoc, pointLightLinear);
    glUniform1f(pointLightLinearLoc, pointLightQuadratic);

    glUniform3f(pointLight2PosLoc, pointLightPositions[1].x, pointLightPositions[1].y, pointLightPositions[1].z);
    glUniform3f(pointLight2AmbientLoc, pointLight2Ambient.x, pointLight2Ambient.y, pointLight2Ambient.z);
    glUniform3f(pointLight2DiffuseLoc, pointLight2Diffuse.x, pointLight2Diffuse.y, pointLight2Diffuse.z);
    glUniform3f(pointLight2SpecularLoc, pointLight2Specular.x, pointLight2Specular.y, pointLight2Specular.z);
    glUniform1f(pointLight2ConstantLoc, pointLight2Constant);
    glUniform1f(pointLight2LinearLoc, pointLight2Linear);
    glUniform1f(pointLight2LinearLoc, pointLight2Quadratic);

    // Draws the triangles
    glDrawElements(GL_TRIANGLES, gMesh.cannVertices, GL_UNSIGNED_INT, NULL); // Draws the triangle

    // Deactivate the Vertex Array Object
    glBindVertexArray(0);
    glUseProgram(0);
    

    // LID: Draw candle lid
    // --------------------------------------------------------
    glUseProgram(gLidProgramId);
    model = glm::translate(gLidPosition) * glm::rotate(radians(90.f), glm::vec3(1.0f, 0.0f, 0.0f)) * glm::scale(gLidScale);

    // Activate the VBOs contained within the mesh's VAO
    glBindVertexArray(gMesh.lidVAO);

    glActiveTexture(GL_TEXTURE0);
    glBindTexture(GL_TEXTURE_2D, gDifTextureIdLid);
    glActiveTexture(GL_TEXTURE1);
    glBindTexture(GL_TEXTURE_2D, gSpecTextureIdLid);

    // Retrieves and passes transform matrices to the Shader program
    modelLoc = glGetUniformLocation(gLidProgramId, "model");
    viewLoc = glGetUniformLocation(gLidProgramId, "view");
    projLoc = glGetUniformLocation(gLidProgramId, "projection");

    // Pass matrix data to the Shader program's matrix uniforms
    glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));
    glUniformMatrix4fv(viewLoc, 1, GL_FALSE, glm::value_ptr(view));
    glUniformMatrix4fv(projLoc, 1, GL_FALSE, glm::value_ptr(projection));

    // Reference matrix uniforms from the Shader program for the object color, light color, light position, and camera position
    matShininessLoc = glGetUniformLocation(gLidProgramId, "material.shininess");
    lightDirectionLoc = glGetUniformLocation(gLidProgramId, "dirLight.direction");
    viewPositionLoc = glGetUniformLocation(gLidProgramId, "viewPosition");
    ambientLightLoc = glGetUniformLocation(gLidProgramId, "dirLight.ambient");
    diffuseLightLoc = glGetUniformLocation(gLidProgramId, "dirLight.diffuse");
    specularLightLoc = glGetUniformLocation(gLidProgramId, "dirLight.specular");

    pointLightPosLoc = glGetUniformLocation(gLidProgramId, "pointLights[0].position");
    pointLightAmbientLoc = glGetUniformLocation(gLidProgramId, "pointLights[0].ambient");
    pointLightDiffuseLoc = glGetUniformLocation(gLidProgramId, "pointLights[0].diffuse");
    pointLightSpecularLoc = glGetUniformLocation(gLidProgramId, "pointLights[0].specular");
    pointLightConstantLoc = glGetUniformLocation(gLidProgramId, "pointLights[0].constant");
    pointLightLinearLoc = glGetUniformLocation(gLidProgramId, "pointLights[0].linear");
    pointLightQuadraticLoc = glGetUniformLocation(gLidProgramId, "pointLights[0].quadratic");

    pointLight2PosLoc = glGetUniformLocation(gLidProgramId, "pointLights[1].position");
    pointLight2AmbientLoc = glGetUniformLocation(gLidProgramId, "pointLights[1].ambient");
    pointLight2DiffuseLoc = glGetUniformLocation(gLidProgramId, "pointLights[1].diffuse");
    pointLight2SpecularLoc = glGetUniformLocation(gLidProgramId, "pointLights[1].specular");
    pointLight2ConstantLoc = glGetUniformLocation(gLidProgramId, "pointLights[1].constant");
    pointLight2LinearLoc = glGetUniformLocation(gLidProgramId, "pointLights[1].linear");
    pointLight2QuadraticLoc = glGetUniformLocation(gLidProgramId, "pointLights[1].quadratic");

    // Pass color, light, and camera data to the Shader program's corresponding uniforms
    glUniform1f(matShininessLoc, lidShine);
    glUniform3f(lightDirectionLoc, dirLightDirection.x, dirLightDirection.y, dirLightDirection.z);
    cameraPosition == gCamera.Position;
    glUniform3f(viewPositionLoc, cameraPosition.x, cameraPosition.y, cameraPosition.z);
    glUniform3f(ambientLightLoc, dirLightAmbient.x, dirLightAmbient.y, dirLightAmbient.z);
    glUniform3f(diffuseLightLoc, dirLightDiffuse.x, dirLightDiffuse.y, dirLightDiffuse.z);
    glUniform3f(specularLightLoc, dirLightSpecular.x, dirLightSpecular.y, dirLightSpecular.z);

    glUniform3f(pointLightPosLoc, pointLightPositions[0].x, pointLightPositions[0].y, pointLightPositions[0].z);
    glUniform3f(pointLightAmbientLoc, pointLightAmbient.x, pointLightAmbient.y, pointLightAmbient.z);
    glUniform3f(pointLightDiffuseLoc, pointLightDiffuse.x, pointLightDiffuse.y, pointLightDiffuse.z);
    glUniform3f(pointLightSpecularLoc, pointLightSpecular.x, pointLightSpecular.y, pointLightSpecular.z);
    glUniform1f(pointLightConstantLoc, pointLightConstant);
    glUniform1f(pointLightLinearLoc, pointLightLinear);
    glUniform1f(pointLightLinearLoc, pointLightQuadratic);

    glUniform3f(pointLight2PosLoc, pointLightPositions[1].x, pointLightPositions[1].y, pointLightPositions[1].z);
    glUniform3f(pointLight2AmbientLoc, pointLight2Ambient.x, pointLight2Ambient.y, pointLight2Ambient.z);
    glUniform3f(pointLight2DiffuseLoc, pointLight2Diffuse.x, pointLight2Diffuse.y, pointLight2Diffuse.z);
    glUniform3f(pointLight2SpecularLoc, pointLight2Specular.x, pointLight2Specular.y, pointLight2Specular.z);
    glUniform1f(pointLight2ConstantLoc, pointLight2Constant);
    glUniform1f(pointLight2LinearLoc, pointLight2Linear);
    glUniform1f(pointLight2LinearLoc, pointLight2Quadratic);

    // Draws the triangles
    glDrawElements(GL_TRIANGLES, gMesh.lidnVertices, GL_UNSIGNED_INT, NULL); // Draws the triangle

    // Deactivate the Vertex Array Object
    glBindVertexArray(0);
    glUseProgram(0);

    // BALL: Draw ball
    // ---------------------------------------------------------
    glUseProgram(gBallProgramId);
    
    model = glm::translate(gBallPosition) * glm::rotate(radians(90.f), glm::vec3(1.0f, 0.0f, 0.0f)) * glm::scale(gBallScale);

    // Activate the VBOs contained within the mesh's VAO
    glBindVertexArray(gMesh.sVAO);

    glActiveTexture(GL_TEXTURE0);
    glBindTexture(GL_TEXTURE_2D, gDifTextureIdBall);
    glActiveTexture(GL_TEXTURE1);
    glBindTexture(GL_TEXTURE_2D, gSpecTextureIdBall);

    // Retrieves and passes transform matrices to the Shader program
    modelLoc = glGetUniformLocation(gBallProgramId, "model");
    viewLoc = glGetUniformLocation(gBallProgramId, "view");
    projLoc = glGetUniformLocation(gBallProgramId, "projection");

    // Pass matrix data to the Shader program's matrix uniforms
    glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));
    glUniformMatrix4fv(viewLoc, 1, GL_FALSE, glm::value_ptr(view));
    glUniformMatrix4fv(projLoc, 1, GL_FALSE, glm::value_ptr(projection));
    
    // Reference matrix uniforms from the Shader program for the object color, light color, light position, and camera position
    matShininessLoc = glGetUniformLocation(gBallProgramId, "material.shininess");
    lightDirectionLoc = glGetUniformLocation(gBallProgramId, "dirLight.direction");
    viewPositionLoc = glGetUniformLocation(gBallProgramId, "viewPosition");
    ambientLightLoc = glGetUniformLocation(gBallProgramId, "dirLight.ambient");
    diffuseLightLoc = glGetUniformLocation(gBallProgramId, "dirLight.diffuse");
    specularLightLoc = glGetUniformLocation(gBallProgramId, "dirLight.specular");

    pointLightPosLoc = glGetUniformLocation(gBallProgramId, "pointLights[0].position");
    pointLightAmbientLoc = glGetUniformLocation(gBallProgramId, "pointLights[0].ambient");
    pointLightDiffuseLoc = glGetUniformLocation(gBallProgramId, "pointLights[0].diffuse");
    pointLightSpecularLoc = glGetUniformLocation(gBallProgramId, "pointLights[0].specular");
    pointLightConstantLoc = glGetUniformLocation(gBallProgramId, "pointLights[0].constant");
    pointLightLinearLoc = glGetUniformLocation(gBallProgramId, "pointLights[0].linear");
    pointLightQuadraticLoc = glGetUniformLocation(gBallProgramId, "pointLights[0].quadratic");

    pointLight2PosLoc = glGetUniformLocation(gBallProgramId, "pointLights[1].position");
    pointLight2AmbientLoc = glGetUniformLocation(gBallProgramId, "pointLights[1].ambient");
    pointLight2DiffuseLoc = glGetUniformLocation(gBallProgramId, "pointLights[1].diffuse");
    pointLight2SpecularLoc = glGetUniformLocation(gBallProgramId, "pointLights[1].specular");
    pointLight2ConstantLoc = glGetUniformLocation(gBallProgramId, "pointLights[1].constant");
    pointLight2LinearLoc = glGetUniformLocation(gBallProgramId, "pointLights[1].linear");
    pointLight2QuadraticLoc = glGetUniformLocation(gBallProgramId, "pointLights[1].quadratic");

    // Pass color, light, and camera data to the Shader program's corresponding uniforms
    glUniform1f(matShininessLoc, bShine);
    glUniform3f(lightDirectionLoc, dirLightDirection.x, dirLightDirection.y, dirLightDirection.z);
    cameraPosition == gCamera.Position;
    glUniform3f(viewPositionLoc, cameraPosition.x, cameraPosition.y, cameraPosition.z);
    glUniform3f(ambientLightLoc, dirLightAmbient.x, dirLightAmbient.y, dirLightAmbient.z);
    glUniform3f(diffuseLightLoc, dirLightDiffuse.x, dirLightDiffuse.y, dirLightDiffuse.z);
    glUniform3f(specularLightLoc, dirLightSpecular.x, dirLightSpecular.y, dirLightSpecular.z);

    glUniform3f(pointLightPosLoc, pointLightPositions[0].x, pointLightPositions[0].y, pointLightPositions[0].z);
    glUniform3f(pointLightAmbientLoc, pointLightAmbient.x, pointLightAmbient.y, pointLightAmbient.z);
    glUniform3f(pointLightDiffuseLoc, pointLightDiffuse.x, pointLightDiffuse.y, pointLightDiffuse.z);
    glUniform3f(pointLightSpecularLoc, pointLightSpecular.x, pointLightSpecular.y, pointLightSpecular.z);
    glUniform1f(pointLightConstantLoc, pointLightConstant);
    glUniform1f(pointLightLinearLoc, pointLightLinear);
    glUniform1f(pointLightLinearLoc, pointLightQuadratic);

    glUniform3f(pointLight2PosLoc, pointLightPositions[1].x, pointLightPositions[1].y, pointLightPositions[1].z);
    glUniform3f(pointLight2AmbientLoc, pointLight2Ambient.x, pointLight2Ambient.y, pointLight2Ambient.z);
    glUniform3f(pointLight2DiffuseLoc, pointLight2Diffuse.x, pointLight2Diffuse.y, pointLight2Diffuse.z);
    glUniform3f(pointLight2SpecularLoc, pointLight2Specular.x, pointLight2Specular.y, pointLight2Specular.z);
    glUniform1f(pointLight2ConstantLoc, pointLight2Constant);
    glUniform1f(pointLight2LinearLoc, pointLight2Linear);
    glUniform1f(pointLight2LinearLoc, pointLight2Quadratic);

    // Draws the triangles
    glDrawElements(GL_TRIANGLES, gMesh.snVertices, GL_UNSIGNED_INT, NULL); // Draws the triangle

    // Deactivate the Vertex Array Object
    glBindVertexArray(0);
    glUseProgram(0);
 
    //-------------------------------------------------- 
    // glfw: swap buffers and poll IO events (keys pressed/released, mouse moved etc.)
    glfwSwapBuffers(gWindow);    // Flips the the back buffer with the front buffer every frame.
}


void UCreateMesh(GLMesh& mesh)
{
    // Position and Color data
    GLfloat chopstick[] = {
        // Vertex Positions       // Normals            // Texture Coordinates
  
   // Front face
        //Triangle 1 (0, 1, 3,)
          4.0f,  0.05f,  0.05f,   0.0f,  0.0f,  1.0f,   1.0f, 1.0f, // Top Right Vertex 0
          4.0f, -0.05f,  0.05f,   0.0f,  0.0f,  1.0f,   1.0f, 0.0f, // Bottom Right Vertex 1
         -4.0f,  0.1f,   0.1f,    0.0f,  0.0f,  1.0f,   0.0f, 1.0f, // Top Left Vertex 3
       // Triangle 2 (1, 2, 3)
          4.0f, -0.05f,  0.05f,   0.0f,  0.0f,  1.0f,   1.0f, 0.0f, // Bottom Right Vertex 1
         -4.0f, -0.1f,   0.1f,    0.0f,  0.0f,  1.0f,   0.0f, 0.0f, // Bottom Left Vertex 2
         -4.0f,  0.1f,   0.1f,    0.0f,  0.0f,  1.0f,   0.0f, 1.0f, // Top Left Vertex 3

   // Right face
       // Triangle 3 (0, 1, 4)
          4.0f,  0.05f,  0.05f,   1.0f,  0.0f,  0.0f,   0.0f, 1.0f, // Top Right Vertex 0
          4.0f, -0.05f,  0.05f,   1.0f,  0.0f,  0.0f,   0.0f, 0.0f, // Bottom Right Vertex 1
          4.0f, -0.05f, -0.05f,   1.0f,  0.0f,  0.0f,   1.0f, 0.0f, // Back bottom right Vertex 4
       // Triangle 4 (0, 4, 5)
          4.0f,  0.05f,  0.05f,   1.0f,  0.0f,  0.0f,   0.0f, 1.0f, // Top Right Vertex 0
          4.0f, -0.05f, -0.05f,   1.0f,  0.0f,  0.0f,   1.0f, 0.0f, // Back bottom right Vertex 4
          4.0f,  0.05f, -0.05f,   1.0f,  0.0f,  0.0f,   1.0f, 1.0f, // Back top right Vertex 5

   // Top
       // Triangle 5 (0, 5, 6)
          4.0f,  0.05f,  0.05f,   0.0f,  1.0f,  0.0f,   1.0f, 0.0f, // Top Right Vertex 0
          4.0f,  0.05f, -0.05f,   0.0f,  1.0f,  0.0f,   1.0f, 1.0f, // Back top right Vertex 5
         -4.0f,  0.1f,  -0.1f,    0.0f,  1.0f,  0.0f,   0.0f, 1.0f, // Back top left Vertex 6
      // Triangle 6 (0, 3, 6)
          4.0f,  0.05f,  0.05f,   0.0f,  1.0f,  0.0f,   1.0f, 0.0f, // Top Right Vertex 0
         -4.0f,  0.1f,   0.1f,    0.0f,  1.0f,  0.0f,   0.0f, 0.0f, // Top Left Vertex 3
         -4.0f,  0.1f,  -0.1f,    0.0f,  1.0f,  0.0f,   0.0f, 1.0f, // Back top left Vertex 6

   // Back
      // Triangle 7 (4, 5, 6)
          4.0f, -0.05f, -0.05f,   0.0f,  0.0f, -1.0f,   0.0f, 0.0f, // Back bottom right Vertex 4
          4.0f,  0.05f, -0.05f,   0.0f,  0.0f, -1.0f,   0.0f, 1.0f, // Back top right Vertex 5
         -4.0f,  0.1f,  -0.1f,    0.0f,  0.0f, -1.0f,   1.0f, 1.0f, // Back top left Vertex 6
      // Triangle 8 (4, 6, 7)
          4.0f, -0.05f, -0.05f,   0.0f,  0.0f, -1.0f,   0.0f, 0.0f, // Back bottom right Vertex 4
         -4.0f,  0.1f,  -0.1f,    0.0f,  0.0f, -1.0f,   1.0f, 1.0f, // Back top left Vertex 6
         -4.0f, -0.1f,  -0.1f,    0.0f,  0.0f, -1.0f,   1.0f, 0.0f, // Back bottom left Vertex 7

   // Left
      // Triangle 9 (2, 3, 6)
         -4.0f, -0.1f,   0.1f,   -1.0f,  0.0f,  0.0f,   1.0f, 0.0f, // Bottom Left Vertex 2
         -4.0f,  0.1f,   0.1f,   -1.0f,  0.0f,  0.0f,   1.0f, 1.0f, // Top Left Vertex 3
         -4.0f,  0.1f,  -0.1f,   -1.0f,  0.0f,  0.0f,   0.0f, 1.0f, // Back top left Vertex 6
      // Triangle 10 (2, 6, 7)
         -4.0f, -0.1f,   0.1f,   -1.0f,  0.0f,  0.0f,   1.0f, 0.0f, // Bottom Left Vertex 2
         -4.0f,  0.1f,  -0.1f,   -1.0f,  0.0f,  0.0f,   0.0f, 1.0f, // Back top left Vertex 6
         -4.0f, -0.1f,  -0.1f,   -1.0f,  0.0f,  0.0f,   0.0f, 0.0f, // Back bottom left Vertex 7
   
   // Bottom
      // Triangle 11 ( 1, 4, 7)
          4.0f, -0.05f,  0.05f,   0.0f, -1.0f,  0.0f,   1.0f, 1.0f, // Bottom Right Vertex 1
          4.0f, -0.05f, -0.05f,   0.0f, -1.0f,  0.0f,   1.0f, 0.0f, // Back bottom right Vertex 4
         -4.0f, -0.1f,  -0.1f,    0.0f, -1.0f,  0.0f,   0.0f, 0.0f, // Back bottom left Vertex 7
      // Triangle 12 (1, 2, 7)
          4.0f, -0.05f,  0.05f,   0.0f, -1.0f,  0.0f,   1.0f, 1.0f, // Bottom Right Vertex 1
         -4.0f, -0.1f,   0.1f,    0.0f, -1.0f,  0.0f,   0.0f, 1.0f, // Bottom Left Vertex 2
         -4.0f, -0.1f,  -0.1f,    0.0f, -1.0f,  0.0f,   0.0f, 0.0f, // Back bottom left Vertex 7

// Tip
     // Triangle 13 (3, 6, 8)
         -4.0f,  0.1f,   0.1f,   -1.0f,  0.0f,  0.0f,   0.0f, 0.0f, // Top Left Vertex 3
         -4.0f,  0.1f,  -0.1f,   -1.0f,  0.0f,  0.0f,   1.0f, 0.0f, // Back top left Vertex 6
         -4.06f, 0.0f,   0.0f,   -1.0f,  0.0f,  0.0f,   0.5f, 1.0f, // Top of pyramid (Tip of chopstick) Vertex 8 
     // Triangle 14 (6, 7, 8)
         -4.0f,  0.1f,  -0.1f,   -1.0f,  0.0f,  0.0f,   0.0f, 0.0f, // Back top left Vertex 6
         -4.0f, -0.1f,  -0.1f,   -1.0f,  0.0f,  0.0f,   1.0f, 0.0f, // Back bottom left Vertex 7
         -4.06f, 0.0f,   0.0f,   -1.0f,  0.0f,  0.0f,   0.5f, 1.0f, // Top of pyramid (Tip of chopstick) Vertex 8
     // Triangle 15 (2, 7, 8)
         -4.0f, -0.1f,   0.1f,   -1.0f,  0.0f,  0.0f,   0.0f, 0.0f, // Bottom Left Vertex 2
         -4.0f, -0.1f,  -0.1f,   -1.0f,  0.0f,  0.0f,   1.0f, 0.0f, // Back bottom left Vertex 7
         -4.06f, 0.0f,   0.0f,   -1.0f,  0.0f,  0.0f,   0.5f, 1.0f, // Top of pyramid (Tip of chopstick) Vertex 8
     // Triangle 16 (2, 3, 8 )
         -4.0f, -0.1f,   0.1f,   -1.0f,  0.0f,  0.0f,   0.0f, 0.0f, // Bottom Left Vertex 2
         -4.0f,  0.1f,   0.1f,   -1.0f,  0.0f,  0.0f,   1.0f, 0.0f, // Top Left Vertex 3
         -4.06f, 0.0f,   0.0f,   -1.0f,  0.0f,  0.0f,   0.5f, 1.0f  // Top of pyramid (Tip of chopstick) Vertex 8
      
    };
    // Index data to share position data
    GLfloat plane[] = {

        // Triangle 1 (0, 2, 4)
         -5.0f,  -0.1f, -5.0f,    0.0f,  1.0f,  0.0f,   0.0f, 1.0f, // 0
          5.0f,  -0.1f,  5.0f,    0.0f,  1.0f,  0.0f,   1.0f, 0.0f, // 2 
         -5.0f,  -0.1f,  5.0f,    0.0f,  1.0f,  0.0f,   1.0f, 1.0f, // 4 
         // Triangle 2 (1, 3, 5)
          5.0f,  -0.1f, -5.0f,    0.0f,  1.0f,  0.0f,   0.0f, 0.0f, // 1  
          5.0f,  -0.1f,  5.0f,    0.0f,  1.0f,  0.0f,   1.0f, 0.0f, // 3 
         -5.0f,  -0.1f, -5.0f,    0.0f,  1.0f,  0.0f,   0.0f, 1.0f  // 5 
    };

    // Position and Color data for cubes
    GLfloat cube[] = {
        //Positions          //Normals
        // ------------------------------------------------------
        //Back Face          //Negative Z Normal  Texture Coords.
       -0.5f, -0.5f, -0.5f,  0.0f,  0.0f, -1.0f,  0.0f, 0.0f,
        0.5f, -0.5f, -0.5f,  0.0f,  0.0f, -1.0f,  1.0f, 0.0f,
        0.5f,  0.5f, -0.5f,  0.0f,  0.0f, -1.0f,  1.0f, 1.0f,
        0.5f,  0.5f, -0.5f,  0.0f,  0.0f, -1.0f,  1.0f, 1.0f,
       -0.5f,  0.5f, -0.5f,  0.0f,  0.0f, -1.0f,  0.0f, 1.0f,
       -0.5f, -0.5f, -0.5f,  0.0f,  0.0f, -1.0f,  0.0f, 0.0f,

       //Front Face         //Positive Z Normal
      -0.5f, -0.5f,  0.5f,  0.0f,  0.0f,  1.0f,  0.0f, 0.0f,
       0.5f, -0.5f,  0.5f,  0.0f,  0.0f,  1.0f,  1.0f, 0.0f,
       0.5f,  0.5f,  0.5f,  0.0f,  0.0f,  1.0f,  1.0f, 1.0f,
       0.5f,  0.5f,  0.5f,  0.0f,  0.0f,  1.0f,  1.0f, 1.0f,
      -0.5f,  0.5f,  0.5f,  0.0f,  0.0f,  1.0f,  0.0f, 1.0f,
      -0.5f, -0.5f,  0.5f,  0.0f,  0.0f,  1.0f,  0.0f, 0.0f,

      //Left Face          //Negative X Normal
      -0.5f,  0.5f,  0.5f, -1.0f,  0.0f,  0.0f,  1.0f, 0.0f,
      -0.5f,  0.5f, -0.5f, -1.0f,  0.0f,  0.0f,  1.0f, 1.0f,
      -0.5f, -0.5f, -0.5f, -1.0f,  0.0f,  0.0f,  0.0f, 1.0f,
      -0.5f, -0.5f, -0.5f, -1.0f,  0.0f,  0.0f,  0.0f, 1.0f,
      -0.5f, -0.5f,  0.5f, -1.0f,  0.0f,  0.0f,  0.0f, 0.0f,
      -0.5f,  0.5f,  0.5f, -1.0f,  0.0f,  0.0f,  1.0f, 0.0f,

      //Right Face         //Positive X Normal
       0.5f,  0.5f,  0.5f,  1.0f,  0.0f,  0.0f,  1.0f, 0.0f,
       0.5f,  0.5f, -0.5f,  1.0f,  0.0f,  0.0f,  1.0f, 1.0f,
       0.5f, -0.5f, -0.5f,  1.0f,  0.0f,  0.0f,  0.0f, 1.0f,
       0.5f, -0.5f, -0.5f,  1.0f,  0.0f,  0.0f,  0.0f, 1.0f,
       0.5f, -0.5f,  0.5f,  1.0f,  0.0f,  0.0f,  0.0f, 0.0f,
       0.5f,  0.5f,  0.5f,  1.0f,  0.0f,  0.0f,  1.0f, 0.0f,

       //Bottom Face        //Negative Y Normal
       -0.5f, -0.5f, -0.5f,  0.0f, -1.0f,  0.0f,  0.0f, 1.0f,
        0.5f, -0.5f, -0.5f,  0.0f, -1.0f,  0.0f,  1.0f, 1.0f,
        0.5f, -0.5f,  0.5f,  0.0f, -1.0f,  0.0f,  1.0f, 0.0f,
        0.5f, -0.5f,  0.5f,  0.0f, -1.0f,  0.0f,  1.0f, 0.0f,
       -0.5f, -0.5f,  0.5f,  0.0f, -1.0f,  0.0f,  0.0f, 0.0f,
       -0.5f, -0.5f, -0.5f,  0.0f, -1.0f,  0.0f,  0.0f, 1.0f,

       //Top Face           //Positive Y Normal
       -0.5f,  0.5f, -0.5f,  0.0f,  1.0f,  0.0f,  0.0f, 1.0f,
        0.5f,  0.5f, -0.5f,  0.0f,  1.0f,  0.0f,  1.0f, 1.0f,
        0.5f,  0.5f,  0.5f,  0.0f,  1.0f,  0.0f,  1.0f, 0.0f,
        0.5f,  0.5f,  0.5f,  0.0f,  1.0f,  0.0f,  1.0f, 0.0f,
       -0.5f,  0.5f,  0.5f,  0.0f,  1.0f,  0.0f,  0.0f, 0.0f,
       -0.5f,  0.5f, -0.5f,  0.0f,  1.0f,  0.0f,  0.0f, 1.0f
    };
   
    // Creates the Vertex Attribute Pointer for the screen coordinates
    const GLuint floatsPerVertex = 3;  // Number of coordinates per vertex
    const GLuint floatsPerNormal = 3;
    const GLuint floatsPerUV = 2;     

    // Vertices per object
    mesh.csnVertices = sizeof(chopstick) / (sizeof(chopstick[0]) * (floatsPerVertex + floatsPerNormal + floatsPerUV));
    mesh.planenVertices = sizeof(plane) / (sizeof(plane[0]) * (floatsPerVertex + floatsPerNormal + floatsPerUV));
    mesh.lnVertices = lightSphere.getIndexCount();
    mesh.l2nVertices = lightSphere2.getIndexCount();
    mesh.cannVertices = cylinder1.getIndexCount();
    mesh.lidnVertices = cylinder2.getIndexCount();
    mesh.snVertices = sphere.getIndexCount();
    mesh.bnVertices = sizeof(cube) / (sizeof(cube[0]) * (floatsPerVertex + floatsPerNormal + floatsPerUV));
   
    // Strides between vertex coordinates is 6 (x, y, z, r, g, b, a). A tightly packed stride is 0.
    GLint stride = sizeof(float) * (floatsPerVertex + floatsPerNormal + floatsPerUV);// The number of floats before each

    // ------ Chopstick ----------

    // Generate VAO and VBO with 1 object each
    glGenVertexArrays(1, &mesh.csVAO);
    glBindVertexArray(mesh.csVAO);

    // Create buffers
    glGenBuffers(1, &mesh.csVBO);
    glBindBuffer(GL_ARRAY_BUFFER, mesh.csVBO); 
    glBufferData(GL_ARRAY_BUFFER, sizeof(chopstick), chopstick, GL_STATIC_DRAW); // Sends vertex or coordinate data to the GPU

    // Create Vertex Attribute Pointers
    glVertexAttribPointer(0, floatsPerVertex, GL_FLOAT, GL_FALSE, stride, 0);
    glEnableVertexAttribArray(0);
    glVertexAttribPointer(1, floatsPerNormal, GL_FLOAT, GL_FALSE, stride, (void*)(sizeof(float) * floatsPerVertex));
    glEnableVertexAttribArray(1);
    glVertexAttribPointer(2, floatsPerUV, GL_FLOAT, GL_FALSE, stride, (void*)(sizeof(float) * (floatsPerVertex + floatsPerNormal)));
    glEnableVertexAttribArray(2);


    // ------------- Plane -------------

    glGenVertexArrays(1, &mesh.planeVAO);			// generate VAO for plane
    glBindVertexArray(mesh.planeVAO);				// bind VAO
    
    glGenBuffers(1, &mesh.planeVBO);				// generate VBO 
    glBindBuffer(GL_ARRAY_BUFFER, mesh.planeVBO);	// Activates the buffer
    glBufferData(GL_ARRAY_BUFFER, sizeof(plane), plane, GL_STATIC_DRAW);

    // Create Vertex Attribute Pointers
    glVertexAttribPointer(0, floatsPerVertex, GL_FLOAT, GL_FALSE, stride, 0);
    glEnableVertexAttribArray(0);
    glVertexAttribPointer(1, floatsPerNormal, GL_FLOAT, GL_FALSE, stride, (void*)(sizeof(float) * floatsPerVertex));
    glEnableVertexAttribArray(1);
    glVertexAttribPointer(2, floatsPerUV, GL_FLOAT, GL_FALSE, stride, (void*)(sizeof(float) * (floatsPerVertex + floatsPerNormal)));
    glEnableVertexAttribArray(2);

    // ------------- Box -------------

    glGenVertexArrays(1, &mesh.bVAO);			// generate VAO for box
    glBindVertexArray(mesh.bVAO);				// bind VAO
    
    glGenBuffers(1, &mesh.bVBO);				// generate VBO 
    glBindBuffer(GL_ARRAY_BUFFER, mesh.bVBO);	// Activates the buffer
    glBufferData(GL_ARRAY_BUFFER, sizeof(cube), cube, GL_STATIC_DRAW);

    // Create Vertex Attribute Pointers
    glVertexAttribPointer(0, floatsPerVertex, GL_FLOAT, GL_FALSE, stride, 0);
    glEnableVertexAttribArray(0);
    glVertexAttribPointer(1, floatsPerNormal, GL_FLOAT, GL_FALSE, stride, (void*)(sizeof(float)* floatsPerVertex));
    glEnableVertexAttribArray(1);
    glVertexAttribPointer(2, floatsPerUV, GL_FLOAT, GL_FALSE, stride, (void*)(sizeof(float)* (floatsPerVertex + floatsPerNormal)));
    glEnableVertexAttribArray(2);

    // ------------- Light 1 -------------------

    glGenVertexArrays(1, &mesh.lVAO);			// generate VAO for light
    glBindVertexArray(mesh.lVAO);				// bind VAO
    
    glGenBuffers(2, mesh.lVBO);				// generate VBO 
    glBindBuffer(GL_ARRAY_BUFFER, mesh.lVBO[0]);	// Activates the buffer
    glBufferData(GL_ARRAY_BUFFER, lightSphere.getInterleavedVertexSize(), lightSphere.getInterleavedVertices(), GL_STATIC_DRAW);

    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, mesh.lVBO[1]);
    glBufferData(GL_ELEMENT_ARRAY_BUFFER, lightSphere.getIndexSize(), lightSphere.getIndices(), GL_STATIC_DRAW);

    // Create Vertex Attribute Pointers
    glVertexAttribPointer(0, floatsPerVertex, GL_FLOAT, GL_FALSE, stride, 0);
    glEnableVertexAttribArray(0);
    glVertexAttribPointer(1, floatsPerNormal, GL_FLOAT, GL_FALSE, stride, (void*)(sizeof(float) * floatsPerVertex));
    glEnableVertexAttribArray(1);
    glVertexAttribPointer(2, floatsPerUV, GL_FLOAT, GL_FALSE, stride, (void*)(sizeof(float) * (floatsPerVertex + floatsPerNormal)));
    glEnableVertexAttribArray(2);

    // ------------- Light 2 -------------------

    glGenVertexArrays(1, &mesh.l2VAO);			// generate VAO for light
    glBindVertexArray(mesh.l2VAO);				// bind VAO

    glGenBuffers(2, mesh.l2VBO);				// generate VBO 
    glBindBuffer(GL_ARRAY_BUFFER, mesh.l2VBO[0]);	// Activates the buffer
    glBufferData(GL_ARRAY_BUFFER, lightSphere2.getInterleavedVertexSize(), lightSphere2.getInterleavedVertices(), GL_STATIC_DRAW);

    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, mesh.l2VBO[1]);
    glBufferData(GL_ELEMENT_ARRAY_BUFFER, lightSphere2.getIndexSize(), lightSphere2.getIndices(), GL_STATIC_DRAW);

    // Create Vertex Attribute Pointers
    glVertexAttribPointer(0, floatsPerVertex, GL_FLOAT, GL_FALSE, stride, 0);
    glEnableVertexAttribArray(0);
    glVertexAttribPointer(1, floatsPerNormal, GL_FLOAT, GL_FALSE, stride, (void*)(sizeof(float)* floatsPerVertex));
    glEnableVertexAttribArray(1);
    glVertexAttribPointer(2, floatsPerUV, GL_FLOAT, GL_FALSE, stride, (void*)(sizeof(float)* (floatsPerVertex + floatsPerNormal)));
    glEnableVertexAttribArray(2);
   
    //-------------- Candle ---------------------

    glGenVertexArrays(1, &mesh.canVAO);			// generate VAO for candle
    glBindVertexArray(mesh.canVAO);				// bind VAO
   
    glGenBuffers(2, mesh.canVBO);				// generate VBO 
    glBindBuffer(GL_ARRAY_BUFFER, mesh.canVBO[0]);	// Activates the buffer
    glBufferData(GL_ARRAY_BUFFER, cylinder1.getInterleavedVertexSize(), cylinder1.getInterleavedVertices(), GL_STATIC_DRAW);

    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, mesh.canVBO[1]);
    glBufferData(GL_ELEMENT_ARRAY_BUFFER, cylinder1.getIndexSize(), cylinder1.getIndices(), GL_STATIC_DRAW);

    // Create Vertex Attribute Pointers
    glVertexAttribPointer(0, floatsPerVertex, GL_FLOAT, GL_FALSE, stride, 0);
    glEnableVertexAttribArray(0);
    glVertexAttribPointer(1, floatsPerNormal, GL_FLOAT, GL_FALSE, stride, (char*)(sizeof(GLfloat)* floatsPerVertex));
    glEnableVertexAttribArray(1);
    glVertexAttribPointer(2, floatsPerUV, GL_FLOAT, GL_FALSE, stride, (char*)(sizeof(GLfloat)* (floatsPerVertex + floatsPerNormal)));
    glEnableVertexAttribArray(2);

    //------------- Candle Lid ----------------------
  
    glGenVertexArrays(1, &mesh.lidVAO);			// generate VAO for lid
    glBindVertexArray(mesh.lidVAO);				// bind VAO

    glGenBuffers(2, mesh.lidVBO);				// generate VBO 
    glBindBuffer(GL_ARRAY_BUFFER, mesh.lidVBO[0]);	// Activates the buffer
    glBufferData(GL_ARRAY_BUFFER, cylinder2.getInterleavedVertexSize(), cylinder2.getInterleavedVertices(), GL_STATIC_DRAW);

    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, mesh.lidVBO[1]);
    glBufferData(GL_ELEMENT_ARRAY_BUFFER, cylinder2.getIndexSize(), cylinder2.getIndices(), GL_STATIC_DRAW);

    // Create Vertex Attribute Pointers
    glVertexAttribPointer(0, floatsPerVertex, GL_FLOAT, GL_FALSE, stride, 0);
    glEnableVertexAttribArray(0);
    glVertexAttribPointer(1, floatsPerNormal, GL_FLOAT, GL_FALSE, stride, (char*)(sizeof(GLfloat)* floatsPerVertex));
    glEnableVertexAttribArray(1);
    glVertexAttribPointer(2, floatsPerUV, GL_FLOAT, GL_FALSE, stride, (char*)(sizeof(GLfloat)* (floatsPerVertex + floatsPerNormal)));
    glEnableVertexAttribArray(2);

    //------------------ Ball -----------------------

    glGenVertexArrays(1, &mesh.sVAO);			// generate VAO for ball
    glBindVertexArray(mesh.sVAO);				// bind VAO

    glGenBuffers(2, mesh.sVBO);				// generate VBO 
    glBindBuffer(GL_ARRAY_BUFFER, mesh.sVBO[0]);	// Activates the buffer
    glBufferData(GL_ARRAY_BUFFER, sphere.getInterleavedVertexSize(), sphere.getInterleavedVertices(), GL_STATIC_DRAW);

    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, mesh.sVBO[1]);
    glBufferData(GL_ELEMENT_ARRAY_BUFFER, sphere.getIndexSize(), sphere.getIndices(), GL_STATIC_DRAW);

    // Create Vertex Attribute Pointers
    glVertexAttribPointer(0, floatsPerVertex, GL_FLOAT, GL_FALSE, stride, 0);
    glEnableVertexAttribArray(0);
    glVertexAttribPointer(1, floatsPerNormal, GL_FLOAT, GL_FALSE, stride, (char*)(sizeof(GLfloat)* floatsPerVertex));
    glEnableVertexAttribArray(1);
    glVertexAttribPointer(2, floatsPerUV, GL_FLOAT, GL_FALSE, stride, (char*)(sizeof(GLfloat)* (floatsPerVertex + floatsPerNormal)));
    glEnableVertexAttribArray(2);
}

void UDestroyMesh(GLMesh& mesh)
{
    glDeleteVertexArrays(1, &mesh.csVAO);
    glDeleteVertexArrays(1, &mesh.planeVAO);
    glDeleteVertexArrays(1, &mesh.lVAO);
    glDeleteVertexArrays(1, &mesh.l2VAO);
    glDeleteVertexArrays(1, &mesh.canVAO);
    glDeleteVertexArrays(1, &mesh.bVAO);
    glDeleteVertexArrays(1, &mesh.sVAO);
    glDeleteVertexArrays(1, &mesh.lidVAO);
    glDeleteBuffers(2, mesh.canVBO);
    glDeleteBuffers(2, mesh.lidVBO);
    glDeleteBuffers(2, mesh.sVBO);
    glDeleteBuffers(1, &mesh.csVBO);
    glDeleteBuffers(1, &mesh.planeVBO);
    glDeleteBuffers(2, mesh.lVBO);
    glDeleteBuffers(2, mesh.l2VBO);
    glDeleteBuffers(1, &mesh.bVBO);

}

/*Generate and load the texture*/
bool UCreateTexture(const char* filename, GLuint& textureId)
{
    int width, height, channels;
    unsigned char* image = stbi_load(filename, &width, &height, &channels, 0);
    if (image)
    {
        flipImageVertically(image, width, height, channels);

        glGenTextures(1, &textureId);
        glBindTexture(GL_TEXTURE_2D, textureId);

        // set the texture wrapping parameters
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
        // set texture filtering parameters
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

        if (channels == 3)
            glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB8, width, height, 0, GL_RGB, GL_UNSIGNED_BYTE, image);
        else if (channels == 4)
            glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA8, width, height, 0, GL_RGBA, GL_UNSIGNED_BYTE, image);
        else
        {
            cout << "Not implemented to handle image with " << channels << " channels" << endl;
            return false;
        }

        glGenerateMipmap(GL_TEXTURE_2D);

        stbi_image_free(image);
        glBindTexture(GL_TEXTURE_2D, 0); // Unbind the texture

        return true;
    }

    // Error loading the image
    return false;
}

void UDestroyTexture(GLuint textureId)
{
    glGenTextures(1, &textureId);
}

// Implements the UCreateShaders function
bool UCreateShaderProgram(const char* vtxShaderSource, const char* fragShaderSource, GLuint& programId)
{
    // Compilation and linkage error reporting
    int success = 0;
    char infoLog[512];

    // Create a Shader program object.
    programId = glCreateProgram();

    // Create the vertex and fragment shader objects
    GLuint vertexShaderId = glCreateShader(GL_VERTEX_SHADER);
    GLuint fragmentShaderId = glCreateShader(GL_FRAGMENT_SHADER);

    // Retrive the shader source
    glShaderSource(vertexShaderId, 1, &vtxShaderSource, NULL);
    glShaderSource(fragmentShaderId, 1, &fragShaderSource, NULL);

    // Compile the vertex shader, and print compilation errors (if any)
    glCompileShader(vertexShaderId); // compile the vertex shader
    // check for shader compile errors
    glGetShaderiv(vertexShaderId, GL_COMPILE_STATUS, &success);
    if (!success)
    {
        glGetShaderInfoLog(vertexShaderId, 512, NULL, infoLog);
        std::cout << "ERROR::SHADER::VERTEX::COMPILATION_FAILED\n" << infoLog << std::endl;

        return false;
    }

    glCompileShader(fragmentShaderId); // compile the fragment shader
    // check for shader compile errors
    glGetShaderiv(fragmentShaderId, GL_COMPILE_STATUS, &success);
    if (!success)
    {
        glGetShaderInfoLog(fragmentShaderId, sizeof(infoLog), NULL, infoLog);
        std::cout << "ERROR::SHADER::FRAGMENT::COMPILATION_FAILED\n" << infoLog << std::endl;

        return false;
    }

    // Attached compiled shaders to the shader program
    glAttachShader(programId, vertexShaderId);
    glAttachShader(programId, fragmentShaderId);

    glLinkProgram(programId);   // links the shader program
    // check for linking errors
    glGetProgramiv(programId, GL_LINK_STATUS, &success);
    if (!success)
    {
        glGetProgramInfoLog(programId, sizeof(infoLog), NULL, infoLog);
        std::cout << "ERROR::SHADER::PROGRAM::LINKING_FAILED\n" << infoLog << std::endl;

        return false;
    }

    glUseProgram(programId);    // Uses the shader program

    return true;
}

void UDestroyShaderProgram(GLuint programId)
{
    glDeleteProgram(programId);
}

